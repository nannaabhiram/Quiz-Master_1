import Login from '../components/Login';

export default function LoginRoute() {
  return <Login />;
}
