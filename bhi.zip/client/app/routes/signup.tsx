import Signup from '../components/Signup';

export default function SignupRoute() {
  return <Signup />;
}
